import { Underwriter } from "./underwriter.model";

describe('Underwriter', () => {
  it('should create an instance', () => {
    // expect(new Underwriter()).toBeTruthy();
  });
});
