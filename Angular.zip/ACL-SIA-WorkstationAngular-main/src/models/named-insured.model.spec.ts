import { NamedInsured } from './named-insured.model';

describe('NamedInsured', () => {
  it('should create an instance', () => {
    expect(new NamedInsured()).toBeTruthy();
  });
});
