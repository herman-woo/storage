import { BrokerCompany } from './broker-company.model';

describe('BrokerCompany', () => {
  it('should create an instance', () => {
    expect(new BrokerCompany()).toBeTruthy();
  });
});
