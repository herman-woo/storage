import { InsuranceBroker } from './insurance-broker.model';

describe('InsuranceBroker', () => {
  it('should create an instance', () => {
    expect(new InsuranceBroker()).toBeTruthy();
  });
});
