import { Component } from '@angular/core';

@Component({
  selector: 'comments-section-card',
  standalone: true,
  imports: [],
  templateUrl: './comments-section-card.component.html',
  styleUrl: './comments-section-card.component.scss'
})
export class CommentsSectionCardComponent {

}
