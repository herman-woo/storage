import { Component } from '@angular/core';

@Component({
  selector: 'history-section-card',
  standalone: true,
  imports: [],
  templateUrl: './history-section-card.component.html',
  styleUrl: './history-section-card.component.scss'
})
export class HistorySectionCardComponent {

}
