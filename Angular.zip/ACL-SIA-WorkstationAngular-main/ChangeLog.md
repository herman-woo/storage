# workstation-app

## Changelog
### version 0.3.6 2024-11-15
Skipped a bunch of updates. Massive Overhaul, Branched account page into tabs. Completed Each tab, RiskSumary, Rating/Quoting, Files, and Account Notes.

### version 0.2.4 2024-11-03
Added the named insured refernce page and individual page.

### version 0.2.3 2024-11-03
Finished bottom section of account page, rating widget, quot widget, notes widget, checklist widget, and RiskWrite widget

### version 0.2.2 2024-11-02
Finished top section of account page

### version 0.2.1 2024-11-02
Started Account page

### version 0.2 2024-11-01
UI overhaul, landing page, sidebar and dashboard implemented

### version 0.1 2024-11-01
basic UI

### version 0.0 2024-11-01
Angular Application stared