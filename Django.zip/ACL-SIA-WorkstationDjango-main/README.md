
# workstation-api
## Start propject
- Step 1: Create an env in project folder directory
```bash
python -m venv workstation_venv
```
- Step 2: Activate a virtual env
```bash
# Mac/ Linux
source activate workstation_venv

# Windows
source workstation-venv\Scripts\activate

# Git Bash
# Step 1
cd workstation_venv/Scripts
# Step 2
. activate 
``` 
- Step 3: Install all dependencies 
```bash 
pip install -r requirements.txt
```
- Step 4: Migrate the db
```bash
python manage.py makemigrate
python manage.py migrate
```
- Step 6: Seed db
```bash
python manage.py seed
```
- Step 5: Run the app
```bash 
python manage.py runserver
```
- To ADD a module
```bash
python manage.py startapp <modulename>
```

## House keeping
- Automate requirement txt
```bash
pip freeze > requirements.txt
```

## Project folder
