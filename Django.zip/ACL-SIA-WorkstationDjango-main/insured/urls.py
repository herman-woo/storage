from django.urls import path
from .views import NamedInsuredView
from . import views

urlpatterns = [
    path("insured", NamedInsuredView.as_view(), name="Named Insured View"),
    path('insured/<int:id>/', views.named_insured_by_id, name="get insured by ID"),
    path('insured/bulk', views.bulk_create, name="bulk create"),
    path('insured/search', views.search_insured, name="Search Insured")
]