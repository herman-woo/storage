from django.contrib import admin
from .models import NamedInsured

admin.site.register(NamedInsured)
