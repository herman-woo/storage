from rest_framework import serializers
from .models import NamedInsured

class NamedInsuredSerializer(serializers.ModelSerializer):
    created_time = serializers.ReadOnlyField()
    updated_time = serializers.ReadOnlyField()

    class Meta:
        model = NamedInsured
        fields = ['id',
                  'name',
                  'address',
                  'postal_code',
                  'province',
                  'created_time',
                  'updated_time']

class NamedInsuredViewSerializer(NamedInsuredSerializer):
    class Meta:
        model = NamedInsured
        fields = ['name','address','postal_code','province']