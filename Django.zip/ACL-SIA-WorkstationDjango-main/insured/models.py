from django.db import models
from locations.models import Province

class NamedInsured(models.Model):
    name = models.CharField(max_length=50, unique=True)
    address = models.CharField(max_length=50, null=True, blank=True)
    postal_code = models.CharField(max_length=7, null=True, blank=True)
    province = models.CharField(max_length=30, choices=Province.choices, null=True, blank=True)
    created_time = models.DateTimeField(auto_now_add=True)  # Set only on creation
    updated_time = models.DateTimeField(auto_now=True)      # Set on each save

    def __str__(self):
        return self.name