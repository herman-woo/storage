from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response
from django.db.models import Q, Value, CharField
from django.db.models.functions import Concat
from django.db import IntegrityError
from .models import NamedInsured
from .serializer import NamedInsuredSerializer
from rest_framework.pagination import PageNumberPagination

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Insured/Named Insured Views

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

"""
# Class Based Views
"""
class NamedInsuredPagination(PageNumberPagination):
    page_size = 30

class NamedInsuredView(generics.GenericAPIView):
    queryset = NamedInsured.objects.all()
    serializer_class = NamedInsuredSerializer
    pagination_class = NamedInsuredPagination

    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)    
    
    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Named Insured
        #   ''''''''''''''''''''''''''''''''''''

        serializer = self.get_serializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    

    #Read
    def get(self, request, *args, **kwargs):
        #  ''''''''''''''''''''''''''''''''''''''''''''''''
        #
        #       GET: Get all Named Insureds
        #        - can filter for single case gets
        #        - has filtering, ordering, and pagination
        #
        #  ''''''''''''''''''''''''''''''''''''''''''''''''

        # search for Query parameters to filter and order by
        filter_name = request.GET.get('name','').strip()
        filter_province = request.GET.get('province','').strip()
        filter_address = request.GET.get('address','').strip()
        filter_postal_code = request.GET.get('postal','').strip()
        order = request.GET.get('order','name').strip()

        # create queryset
        queryset = self.get_queryset().filter(
            Q(name__icontains=filter_name)
            & (Q(province__icontains=filter_province) | Q(province__isnull=True))
            & (Q(address__icontains=filter_address) | Q(address__isnull=True))
            & (Q(postal_code__icontains=filter_postal_code) | Q(postal_code__isnull=True))
        ).order_by(order)

        # get pagination, which limits the amount of items returned
        page = self.paginate_queryset(queryset)
        # serialized the filitered, ordered, and paginated data
        serializer = self.get_serializer(page, many=True)
        # create a pangination response, that comes with all the meta data of the page
        paginated_response = self.get_paginated_response(serializer.data).data


        return Response({
            'success': True,
            'count': paginated_response.get('count', 0),
            'next': paginated_response.get('next'),
            'previous': paginated_response.get('previous'),
            'results': paginated_response.get('results')
        },status=status.HTTP_200_OK)

"""
# Function Based Views
"""
    
#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def named_insured_by_id(request,id):
    
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single Named Insured by ID
    #       PATCH: Paritially updates a Named Insured by ID
    #       DELETE: Removes a single Named Insured by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''

    #Validate Existing Underwriter by ID
    try:
        queryset = NamedInsured.objects.get(id = id)
    except NamedInsured.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    #Get by ID
    if request.method == 'GET':
        serializer = NamedInsuredSerializer(queryset)
        return Response(serializer.data)

    #Edit/Update by ID
    elif request.method == 'PATCH':
        serializer = NamedInsuredSerializer(queryset, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Save the updated record
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Delete by ID
    elif request.method == 'DELETE':
        queryset.delete()
        return Response({"message": "Named Insured deleted successfully"}, status=status.HTTP_200_OK)


@api_view(['POST'])
def bulk_create(request):
    # Ensure data is provided as a list of objects
    if not isinstance(request.data, list):
        return Response({"error": "Expected a list of objects"}, status=status.HTTP_400_BAD_REQUEST)

    # Parse data to create NamedInsured instances
    insured_objects = []
    for item in request.data:
        serializer = NamedInsuredSerializer(data=item)
        if serializer.is_valid():
            insured_objects.append(NamedInsured(**serializer.validated_data))
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # Bulk create in the database
    NamedInsured.objects.bulk_create(insured_objects)

    return Response({"message": "Bulk create successful"}, status=status.HTTP_201_CREATED)

@api_view(['GET'])
def search_insured(request):
    query = request.GET.get('query','').strip()

    if not query:
        return Response([],status=status.HTTP_200_OK)
    
    insured = NamedInsured.objects.filter(
        Q(name__icontains=query)
    )

    serializer = NamedInsuredSerializer(insured, many=True)

    return Response(serializer.data, status=status.HTTP_200_OK)


def create_named_insured_by_name(insured_name):
    try:
        named_insured = NamedInsured.objects.create(name=insured_name)
        return named_insured
    except IntegrityError as e:
        return Response(status=status.HTTP_409_CONFLICT)
