from django.db import models

class Province(models.TextChoices):
        ON = "Ontario"
        BC = "British Colombia"
        QC = "Quebec"
        AB = "Alberta"
        SA = "Saskatchewan"
        MN = "Manitoba"
        NS = "Nova Scotia"
        NF = "New Foundland And Labradour"
        PE = "Prince Edward Island"
        NB = "New Brunswick"

class City(models.Model):
    city_name = models.CharField(max_length=50)
    province = models.CharField(max_length=50, choices=Province.choices, default=Province.ON )

class ProjectSite(models.Model):
      site_name = models.CharField(max_length=50)