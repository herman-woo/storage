from django.urls import path
from . import views
from .views import UnderwriterView,BusinessUnitView, TeamView


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
CARRIER
TODO:
    - Must create view for 'BusinessUnit' and 'Team'

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

# underwriter views
urlpatterns = [
    path('underwriter', UnderwriterView.as_view(), name="Underwriter View"),
    path('underwriter/<int:id>/', views.underwriter_by_id, name="Underwriter by ID"),
    path('underwriter/search', views.search, name='search'),
    path('businessunit', BusinessUnitView.as_view(), name='Business Unit View'),
    path('businessunit/<int:id>/', views.business_unit_by_id, name='Business Unit By ID'),
    path('businessunit/<str:unit_code>/team/<str:team_code>', views.teams_by_code, name='Business Unit By ID'),
    # path('team/<str:code>', TeamView.as_view(), name='Business Unit View'),
]

