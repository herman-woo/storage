from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response
from django.db.models import Q, Value, CharField
from django.db.models.functions import Concat
from .models import Underwriter, BusinessUnit, Team
from .serializer import UnderwriterSerializer, BusinessUnitSerializer, TeamSerializer
from rest_framework.pagination import PageNumberPagination


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Carrier/Underwriter Views

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

"""
# Class Based Views
"""
class UnderwriterPagination(PageNumberPagination):
    page_size = 10

class UnderwriterView(generics.GenericAPIView):
    queryset = Underwriter.objects.all()
    serializer_class = UnderwriterSerializer
    pagination_class = UnderwriterPagination

    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Underwriter
        #   ''''''''''''''''''''''''''''''''''''

        serializer = UnderwriterSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    #Read
    def get(self, request, *args, **kwargs):
        #  ''''''''''''''''''''''''''''''''''''''''''''''''
        #
        #       GET: Get all Underwriters
        #        - can filter for single case gets
        #        - has filtering, ordering, and pagination
        #
        #  ''''''''''''''''''''''''''''''''''''''''''''''''

        # search for Query parameters to filter and order by
        filter_business_unit = request.GET.get('unit','').strip()
        filter_team = request.GET.get('team','').strip()
        filter_first_name = request.GET.get('firstname','').strip()
        filter_last_name = request.GET.get('lastname','').strip()
        order = request.GET.get('order','id').strip()

        # create queryset
        queryset = self.get_queryset().filter(
            Q(business_unit__name=filter_business_unit)
            & Q(team__name__icontains=filter_team)
            & Q(first_name__icontains=filter_first_name)
            & Q(last_name__icontains=filter_last_name)
        ).order_by(order)

        # get pagination, which limits the amount of items returned
        page = self.paginate_queryset(queryset)
        # serialized the filitered, ordered, and paginated data
        serializer = self.get_serializer(page, many=True)
        # create a pangination response, that comes with all the meta data of the page
        paginated_response = self.get_paginated_response(serializer.data).data


        return Response({
            'success': True,
            'count': paginated_response.get('count', 0),
            'next': paginated_response.get('next'),
            'previous': paginated_response.get('previous'),
            'results': paginated_response.get('results')
        },status=status.HTTP_200_OK)

"""
# Functional Views
"""

#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def underwriter_by_id(request,id):
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single Underwriter by ID
    #       PATCH: Paritially updates an Underwriter by ID
    #       DELETE: Removes a single Underwriter by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''

    #Validate Existing Underwriter by ID
    try:
        underwriter = Underwriter.objects.get(id = id)
    except Underwriter.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    #Get by ID
    if request.method == 'GET':
        serializer = UnderwriterSerializer(underwriter)
        return Response(serializer.data)

    #Edit/Update by ID
    elif request.method == 'PATCH':
        serializer = UnderwriterSerializer(underwriter, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Save the updated record
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Delete by ID
    elif request.method == 'DELETE':
        underwriter.delete()
        return Response({"message": "Underwriter deleted successfully"}, status=status.HTTP_200_OK)


# Search Underwriters by a single input against all fields
@api_view(['GET'])
def search(request):
    query = request.GET.get('query','').strip()
    if not query:
        return Response([],status=status.HTTP_200_OK)
    underwriter = Underwriter.objects.annotate(
            full_name=Concat(
                'first_name',
                Value(' '),
                'last_name',
                output_field=CharField()
            )
        ).filter(
        Q(id__icontains=query) |
        Q(first_name__icontains=query) |
        Q(last_name__icontains=query) |
        Q(full_name__icontains=query) |
        Q(business_unit__name__icontains=query) |
        Q(team__name__icontains=query)
    )
    serializer = UnderwriterSerializer(underwriter, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)




'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Carrier/Business Unit + Teams Views

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

class BusinessUnitView(generics.GenericAPIView):

    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Business Unit
        #   ''''''''''''''''''''''''''''''''''''

        serializer = BusinessUnitSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        #   ''''''''''''''''''''''''''''''''''''
        #       GET: Get all business units
        #   ''''''''''''''''''''''''''''''''''''
    def get(self, request, *args, **kwargs):
        filter_by_name = request.GET.get('unit','').strip()
        filter_by_code = request.GET.get('code','').strip()
        queryset = BusinessUnit.objects.all().filter(
            Q(name__icontains=filter_by_name)
            & Q(code__icontains=filter_by_code)
        ).order_by('name')
        serializer = BusinessUnitSerializer(queryset,many=True)
        return Response(serializer.data)
    
#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def business_unit_by_id(request,id):
    
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single Business Unit by ID
    #       PATCH: Paritially updates a Business Unit by ID
    #       DELETE: Removes a single Business Unit by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''

    #Validate Existing Underwriter by ID
    try:
        business_unit = BusinessUnit.objects.get(id = id)
    except BusinessUnit.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    #Get by ID
    if request.method == 'GET':
        serializer = BusinessUnitSerializer(business_unit)
        return Response(serializer.data)

    #Edit/Update by ID
    elif request.method == 'PATCH':
        serializer = BusinessUnitSerializer(business_unit, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Save the updated record
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Delete by ID
    elif request.method == 'DELETE':
        business_unit.delete()
        return Response({"message": "Business Unit deleted successfully"}, status=status.HTTP_200_OK)

class TeamView(generics.GenericAPIView):

    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Business Unit
        #   ''''''''''''''''''''''''''''''''''''
        print("Create Team")
        serializer = TeamSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    #Read
    def get(self, request, *args, **kwargs):
        filter_business_unit = request.GET.get('unit','').strip()
        queryset = Team.objects.filter(
            Q(business_unit__name=filter_business_unit)
        )
        serializer = TeamSerializer(queryset,many=True)
        return Response(serializer.data)

#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def teams_by_code(request,unit_code,team_code):
    
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single Team by ID
    #       PATCH: Paritially updates a Business Unit by ID
    #       DELETE: Removes a single Business Unit by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''




    #Validate Existing Underwriter by ID
    try:
        team = Team.objects.get(code = team_code)
    except Team.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    # #Get by ID
    if request.method == 'GET':
        serializer = TeamSerializer(team)
        return Response(serializer.data, status=status.HTTP_200_OK)

    # #Edit/Update by ID
    # elif request.method == 'PATCH':
    #     serializer = BusinessUnitSerializer(business_unit, data=request.data, partial=True)
    #     if serializer.is_valid():
    #         serializer.save()  # Save the updated record
    #         return Response(serializer.data, status=status.HTTP_200_OK)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    # #Delete by ID
    # elif request.method == 'DELETE':
    #     business_unit.delete()
    #     return Response({"message": "Business Unit deleted successfully"}, status=status.HTTP_200_OK)