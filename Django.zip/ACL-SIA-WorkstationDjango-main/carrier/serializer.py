from rest_framework import serializers
from .models import Underwriter, BusinessUnit, Team

#Serializer that returns the entire Underwriter Model with Business Unit and Team Names
class UnderwriterSerializer(serializers.ModelSerializer):
    created_time = serializers.ReadOnlyField()
    updated_time = serializers.ReadOnlyField()
    business_unit_name = serializers.SerializerMethodField()
    team_name = serializers.SerializerMethodField()

    class Meta:
        model = Underwriter
        fields = ['id',
                  'first_name',
                  'last_name',
                  'business_unit',
                  'business_unit_name',
                  'team',
                  'team_name',
                  'role',
                  'created_time',
                  'updated_time',
                  ]
    
    def get_business_unit_name(self, obj):
        return obj.business_unit.name if obj.business_unit else None
    
    def get_team_name(self, obj):
        return obj.team.name if obj.team else None
    
#Smaller View Serializer for Account
class UnderwriterViewSerializer(UnderwriterSerializer):
    class Meta:
        model = Underwriter
        fields = ['first_name','last_name','business_unit_name','team_name','role',]


class BusinessUnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessUnit
        fields = ['id',
                'name',
                'code',
                ]
            
class TeamSerializer(serializers.ModelSerializer):
    business_unit_name = serializers.SerializerMethodField()
    class Meta:
        model = Team
        fields = ['id',
                    'business_unit',
                    'business_unit_name',
                    'name',
                    'code',
                ]
    def get_business_unit_name(self, obj):
        return obj.business_unit.name if obj.business_unit else None
    