from django.contrib import admin
from .models import Underwriter
from .models import BusinessUnit
from .models import Team

admin.site.register(BusinessUnit)
admin.site.register(Underwriter)
admin.site.register(Team)

