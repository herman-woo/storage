#Carrier Model

from django.db import models

class BusinessUnit(models.Model):
    '''
    Represents the main Business Unit within the Insurance Carrier Company that Underwriters are filtered into.
    '''
    name = models.CharField(max_length=30, unique=True)
    code = models.CharField(max_length=3, unique=True)
    def __str__(self):
        return self.name+', '+self.code

class Team(models.Model):
    '''
    Under each Business Unit, Teams act as further subdivision to handle more specific jobs, this class will be a child of BusinessUnit
    '''
    name = models.CharField(max_length=30)
    code = models.CharField(max_length=3, unique=True)
    business_unit = models.ForeignKey(BusinessUnit,on_delete=models.PROTECT, related_name='team')
    def __str__(self):
        return self.business_unit.name+' '+self.name

class Role(models.TextChoices):
    MA = "Manager"
    UW = "Underwriter"

class Underwriter(models.Model):
    '''
    Underwriters create accounts to rate risks, and generate policies for clients. 
    '''
    #Personal Identity
    first_name = models.CharField(max_length=15, db_index=True)
    last_name = models.CharField(max_length=15, db_index=True)
    #Business Identifiers
    business_unit = models.ForeignKey(BusinessUnit,on_delete=models.PROTECT, related_name='underwriter')
    team = models.ForeignKey(Team,on_delete=models.PROTECT, related_name='underwriter')
    role = models.CharField(max_length=15, choices=Role.choices, default=Role.UW)
    #Record Data
    created_time = models.DateTimeField(auto_now_add=True)  # Set only on creation
    updated_time = models.DateTimeField(auto_now=True)      # Set on each save
    
    def __str__(self):
        return self.first_name+' '+self.last_name