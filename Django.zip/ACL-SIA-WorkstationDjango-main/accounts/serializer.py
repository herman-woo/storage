from rest_framework import serializers
from .models import InsuranceAccount
from brokerage.serializer import InsuredBrokerViewSerializer, BrokerCompanyViewSerializer
from insured.serializer import NamedInsuredViewSerializer
from carrier.serializer import UnderwriterViewSerializer, BusinessUnitSerializer, TeamSerializer


class InsuranceAccountSerializer(serializers.ModelSerializer):
    underwriter_data = UnderwriterViewSerializer(source='underwriter',read_only=True) 
    business_unit_data = BusinessUnitSerializer(source='business_unit', read_only=True)
    team_data = TeamSerializer(source='team', read_only=True)
    named_insured_data = NamedInsuredViewSerializer(source='named_insured', read_only=True)
    broker_data = InsuredBrokerViewSerializer(source='broker', read_only=True)
    broker_company_data = BrokerCompanyViewSerializer(source='broker_company', read_only=True)
    created_time = serializers.ReadOnlyField()
    updated_time = serializers.ReadOnlyField()

    class Meta:
        model = InsuranceAccount
        fields = ['id',
                  'business_unit',
                  'business_unit_data',
                  'underwriter',
                  'underwriter_data',
                  'team',
                  'team_data',
                  'named_insured',
                  'named_insured_data',
                  'broker',
                  'broker_data',
                  'broker_company',
                  'broker_company_data',
                  'submission_type',
                  'year',
                  'policy_id',
                  'previous_account',
                  'product_type',
                  'account_status',
                  'indicated',
                  'quote_revisions_count',
                  'final_quote',
                  'has_policy',
                  'riskwrite_submitted',
                  'riskwrite_bound',
                  'policy_start_date',
                  'policy_end_date',
                  'created_time',
                  'updated_time',
                  ]