from rest_framework import generics,status
from rest_framework.decorators import api_view
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from django.db.models import Q, Value, CharField
from django.db.models.functions import Concat
from django.core.paginator import Paginator

from brokerage.views import BrokerCompanyView, create_company_by_name
from brokerage.models import BrokerCompany
from insured.views import NamedInsuredView, create_named_insured_by_name
from insured.models import NamedInsured
from .models import InsuranceAccount
from .serializer import InsuranceAccountSerializer


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Insurance Acocunt - Views

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

"""
# Class Based Views
"""
class InsuranceAccountPagination(PageNumberPagination):
    page_size = 100

class InsuranceAccountView(generics.GenericAPIView):
    queryset = InsuranceAccount.objects.all()
    serializer_class = InsuranceAccountSerializer
    pagination_class = InsuranceAccountPagination

    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Named Insured
        #   ''''''''''''''''''''''''''''''''''''

        serializer = InsuranceAccountSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    
    #Read
    def get(self, request, *args, **kwargs):
        #  ''''''''''''''''''''''''''''''''''''''''''''''''
        #
        #       GET: Get all Broker Companies
        #        - has filtering, ordering, and pagination
        #
        #  ''''''''''''''''''''''''''''''''''''''''''''''''

        # search for Query parameters to filter and order by
        filter_by_unit = request.GET.get('unit','').strip()
        filter_by_insured_name = request.GET.get('insured', "")
        filter_by_underwriter = request.GET.get('underwriter', "")
        filter_by_broker = request.GET.get('broker', "")
        filter_by_brokerage = request.GET.get('brokerage', "")

        # create queryset
        queryset = InsuranceAccount.objects.annotate(
            underwriter_name=Concat(
                'underwriter__first_name',
                Value(' '),
                'underwriter__last_name',
                output_field=CharField()
            ),
            broker_name=Concat(
                'broker__first_name',
                Value(' '),
                'broker__last_name',
                output_field=CharField()
            ),
        ).filter(
            Q(named_insured__name__icontains=filter_by_insured_name)
            & Q(underwriter_name__icontains=filter_by_underwriter)
            & Q(broker_name__icontains=filter_by_broker)
            & Q(broker_company__name__icontains=filter_by_brokerage)
        ).order_by('-updated_time')

        filter_by_year = request.GET.get('year', "")
        if filter_by_year:  # Only add gender filter if provided
            queryset = queryset.filter(year=filter_by_year)
        filter_by_submission = request.GET.get('submission', "")
        if filter_by_submission:  # Only add gender filter if provided
            queryset = queryset.filter(submission_type=filter_by_submission)

        filter_by_status = request.GET.get('status', "")
        if filter_by_status:  # Only add gender filter if provided
            queryset = queryset.filter(account_status=filter_by_status)

        # get pagination, which limits the amount of items returned
        page = self.paginate_queryset(queryset)
        # serialized the filitered, ordered, and paginated data
        serializer = self.get_serializer(page, many=True)
        # create a pangination response, that comes with all the meta data of the page
        paginated_response = self.get_paginated_response(serializer.data).data


        return Response({
            'success': True,
            'count': paginated_response.get('count', 0),
            'next': paginated_response.get('next'),
            'previous': paginated_response.get('previous'),
            'results': paginated_response.get('results')
        },status=status.HTTP_200_OK)

"""
# Function Based Views
"""
#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def account_by_id(request,id):
    
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single record by ID
    #       PATCH: Paritially updates a record by ID
    #       DELETE: Removes a single record by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''

    #Validate Existing Underwriter by ID
    try:
        queryset = InsuranceAccount.objects.get(id = id)
    except InsuranceAccount.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    #Get by ID
    if request.method == 'GET':
        serializer = InsuranceAccountSerializer(queryset)
        return Response(serializer.data)

    #Edit/Update by ID
    elif request.method == 'PATCH':
        serializer = InsuranceAccountSerializer(queryset, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Save the updated record
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Delete by ID
    elif request.method == 'DELETE':
        queryset.delete()
        return Response({"message": "Named Insured deleted successfully"}, status=status.HTTP_200_OK)

    
@api_view(['GET'])
def get_acc_by_foreign_key(request, param, id):
    if param:
        queryset = InsuranceAccount.objects.filter(**{param: id})
        # page = InsuranceAccountPagination(queryset)
        paginator = Paginator(queryset,15)
        paginated_data = paginator.page(1)
        serializer = InsuranceAccountSerializer(paginated_data.object_list, many=True)

        return Response({
            'success': True,
            'count': paginator.count,
            # 'next': paginated_response.page
            # 'previous': paginated_response.get('previous'),
            'results': serializer.data
        },status=status.HTTP_200_OK)
    

@api_view(['POST'])
def new_submission(request):
    # ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       POST: This endpoint creates a new Named Insured and a new account with it
    #   
    # ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    print("New Sub")

    #Get the named insured name, Handle creating a new one or using an old one and send it over
    insured_name = request.data.get("named_insured")
    company_name = request.data.get("broker_company")
    if insured_name == '' or company_name == '':
        return Response({"Error":"Named Insured or Company Name is blank"},status=status.HTTP_400_BAD_REQUEST)
    
    try:
        insured = NamedInsured.objects.get(name=insured_name)
        print("Use Existing Named insured")
    except:
        print("Create new Named insured")
        insured = create_named_insured_by_name(insured_name)

    
    try:
        company = BrokerCompany.objects.get(name=company_name)
        print("Use Existing Broker Company")
    except:
        print("Create new Broker Company")
        company = create_company_by_name(company_name)

    print(company)

    new_submission = request.data.copy()
    new_submission['named_insured'] = insured.id
    new_submission['broker_company'] = company.id
    print(new_submission)

    serializer = InsuranceAccountSerializer(data = new_submission)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED) 
    else:
        serializer.error_messages
        return Response({"error": serializer.error_messages},status=status.HTTP_400_BAD_REQUEST)