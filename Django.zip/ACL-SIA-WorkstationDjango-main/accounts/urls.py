from django.urls import path
from .views import InsuranceAccountView
from . import views


# underwriter views
urlpatterns = [
    path("", InsuranceAccountView.as_view(), name="index"),
    path('<int:id>/', views.account_by_id, name="get Account"),
    path('key/<str:param>/<int:id>/', views.get_acc_by_foreign_key, name="get Account by Foreign Key"),
    path('submission/new', views.new_submission, name="New Account Submission")
]