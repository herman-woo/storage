from django.contrib import admin
from .models import InsuranceAccount

admin.site.register(InsuranceAccount)