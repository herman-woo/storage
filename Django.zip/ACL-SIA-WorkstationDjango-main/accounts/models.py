from django.db import models
from carrier.models import Underwriter,BusinessUnit,Team
from insured.models import NamedInsured
from brokerage.models import InsuranceBroker,BrokerCompany

class SubmissionType(models.TextChoices):
    NEW = "New"
    REN = "Renewal"

class AccountStatus(models.TextChoices):
    # DRAFT = "Draft"
    SUB = "Submitted"
    RATE = "Rating/Quoting"
    BOUND = "Bound"
    # EXP = "Completed/Expired"

class ProductType(models.TextChoices):
    CPP = "Consultant Or Contractor"
    FSE = "Fixed Site Environmental"
    PPP = "Pollution Protection Policy"
    EXC = "Excess"

class InsuranceAccount(models.Model):
    #Entities Linked with Account - Underwriter, Named Insured, Contact - Broker, Broker Company
    underwriter = models.ForeignKey(Underwriter, on_delete=models.PROTECT, related_name='linked_accounts')
    named_insured = models.ForeignKey(NamedInsured, on_delete=models.PROTECT, related_name='linked_accounts')
    broker = models.ForeignKey(InsuranceBroker, on_delete=models.PROTECT, related_name='linked_accounts')
    broker_company = models.ForeignKey(BrokerCompany, on_delete=models.PROTECT, related_name='linked_accounts')
    # #Account Details
    business_unit = models.ForeignKey(BusinessUnit, on_delete=models.PROTECT, related_name='linked_accounts')
    team = models.ForeignKey(Team, on_delete=models.PROTECT, related_name='linked_accounts')
    submission_type = models.CharField(max_length=7, choices=SubmissionType.choices, default=SubmissionType.NEW )
    year = models.IntegerField()
    #Submission, Renewal. If Account is a renewal, must link previous account
    previous_account = models.ForeignKey('self', on_delete=models.PROTECT, null=True,blank=True, related_name='renewals')
    
    policy_id = models.CharField(max_length=12, unique=True, null=True, blank=True)
    
    '''
    Product will be a ForeignKey to another table
    '''
    product_type = models.CharField(max_length=50, choices=ProductType.choices, null=True, blank=True)

    #Account State: What has been done or not.
    account_status = models.CharField(max_length=30, choices=AccountStatus.choices, default=AccountStatus.SUB )
    indicated = models.BooleanField(default=False)
    quote_revisions_count = models.IntegerField(default=0)
    final_quote = models.BooleanField(default=False)
    has_policy = models.BooleanField(default=False)

    #RiskWrite Booleans
    riskwrite_submitted = models.BooleanField(default=False)
    riskwrite_bound = models.BooleanField(default=False)
    
    #Important Dates
    policy_start_date = models.CharField(max_length=10, null=True,blank=True,)
    policy_end_date = models.CharField(max_length=10, null=True,blank=True,)
    created_time = models.DateTimeField(auto_now_add=True)  # Set only on creation
    updated_time = models.DateTimeField(auto_now=True)      # Set on each save

    # def __str__(self):
    #     return self.policy_id+' '+self.named_insured