from django.contrib import admin
from.models import BrokerCompany,InsuranceBroker

admin.site.register(BrokerCompany)
admin.site.register(InsuranceBroker)
