from rest_framework import serializers
from .models import InsuranceBroker
from .models import BrokerCompany

        
class BrokerCompanySerializer(serializers.ModelSerializer):
    created_time = serializers.ReadOnlyField()
    updated_time = serializers.ReadOnlyField()
    parent_company_name = serializers.SerializerMethodField()

    class Meta:
        model = BrokerCompany
        fields = ['id',
                  'company_id',
                  'name',
                  'address',
                  'postal_code',
                  'city',
                  'province',
                  'is_top_level',
                  'company_level',
                  'parent_company',
                  'parent_company_name',
                  'created_time',
                  'updated_time']
    
    def get_parent_company_name(self, obj):
        return obj.parent_company.name if obj.parent_company else None
        
class BrokerCompanyViewSerializer(serializers.ModelSerializer):
    class Meta:
        model = BrokerCompany
        fields = ['name','address','postal_code','city','province']


class InsuredBrokerSerializer(serializers.ModelSerializer):

    created_time = serializers.ReadOnlyField()
    updated_time = serializers.ReadOnlyField()
    broker_company_name = serializers.SerializerMethodField()

    class Meta:
        model = InsuranceBroker
        fields = ['id',
                  'first_name',
                  'last_name',
                  'title',
                  'phone_number',
                  'email',
                  'broker_company',
                  'broker_company_name',
                  'created_time',
                  'updated_time']
    
    def get_broker_company_name(self, obj):
        return obj.broker_company.name if obj.broker_company else None
    
class InsuredBrokerViewSerializer(InsuredBrokerSerializer):
    class Meta:
        model = InsuranceBroker
        fields = ['first_name','last_name','title','phone_number','email']