from django.db import models
from locations.models import Province


class BrokerCompany(models.Model):
    company_id = models.IntegerField(null=True, blank=True)
    name = models.CharField(max_length=50, unique=True)
    address = models.CharField(max_length=55, null=True, blank=True,)
    postal_code = models.CharField(max_length=6, null=True, blank=True)
    city = models.CharField(max_length=15, db_index=True, null=True, blank=True)
    province = models.CharField(max_length=30, choices=Province.choices, default=Province.ON,db_index=True)
    is_top_level = models.BooleanField(default=False)
    company_level = models.IntegerField(db_index=True,null=True, blank=True)
    parent_company = models.ForeignKey('self', on_delete=models.PROTECT, null=True, blank=True, related_name='subsidiaries')
    created_time = models.DateTimeField(auto_now_add=True)  # Set only on creation
    updated_time = models.DateTimeField(auto_now=True)      # Set on each save

    def __str__(self):
        return self.name

class InsuranceBroker(models.Model):
    first_name = models.CharField(max_length=15)
    last_name = models.CharField(max_length=15)
    title = models.CharField(max_length=15, null=True, blank=True)
    phone_number = models.CharField(max_length=15, null=True, blank=True)
    email = models.CharField(max_length=50, null=True, blank=True)
    broker_company = models.ForeignKey(BrokerCompany, on_delete=models.PROTECT, related_name='brokers')
    created_time = models.DateTimeField(auto_now_add=True)  # Set only on creation
    updated_time = models.DateTimeField(auto_now=True)      # Set on each save
    def __str__(self):
        return self.first_name+' '+self.last_name