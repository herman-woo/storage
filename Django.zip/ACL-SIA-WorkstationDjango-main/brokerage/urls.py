from django.urls import path
from .views import BrokerCompanyView, InsuranceBrokerView
from . import views


# brokerage views
urlpatterns = [
    path("company/", BrokerCompanyView.as_view(), name="Broker Company View"),
    path('company/<int:id>/', views.broker_company_by_id, name="Company By ID"),
    path('company/bulk/', views.bulk_create, name="Bulk Create Companies"),
    path('company/search', views.search_company, name='search_brokers'),

    path("broker/", InsuranceBrokerView.as_view(), name="Insurance Broker View"),
    path('broker/<int:id>/', views.insurance_broker_by_id, name="get Broker"),
    path('broker/bulk/', views.bulk_create, name="Bulk Create Brokers"),
    path('broker/search', views.search_broker, name='search_brokers'),
]