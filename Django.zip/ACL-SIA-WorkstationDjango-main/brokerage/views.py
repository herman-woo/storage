from rest_framework import generics,status
from rest_framework.decorators import api_view
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from django.db import IntegrityError
from django.db.models import Q, Value, CharField
from django.db.models.functions import Concat

from .models import BrokerCompany, InsuranceBroker
from .serializer import InsuredBrokerSerializer, BrokerCompanySerializer


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Brokerage/Company - Views

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

"""
# Class Based Views
"""
class BrokerComapnyPagination(PageNumberPagination):
    page_size = 30

class BrokerCompanyView(generics.GenericAPIView):
    queryset = BrokerCompany.objects.all()
    serializer_class = BrokerCompanySerializer
    pagination_class = BrokerComapnyPagination

    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Named Insured
        #   ''''''''''''''''''''''''''''''''''''

        serializer = self.get_serializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    
    
    #Read
    def get(self, request, *args, **kwargs):
        print("BrokerCompanyView, GET")
        #  ''''''''''''''''''''''''''''''''''''''''''''''''
        #
        #       GET: Get all Broker Companies
        #        - has filtering, ordering, and pagination
        #
        #  ''''''''''''''''''''''''''''''''''''''''''''''''

        # search for Query parameters to filter and order by
        filter_by_name = request.GET.get('name','').strip()
        filter_by_address = request.GET.get('address','').strip()
        filter_by_province = request.GET.get('province','').strip()
        filter_by_postal_code = request.GET.get('postal','').strip()
        filter_by_city = request.GET.get('city','').strip()
        # filter_by_top = request.GET.get('top',False).strip()
        filter_by_parent = request.GET.get('parent','').strip()
        order = request.GET.get('order','name').strip()

        # create queryset
        queryset = self.get_queryset().filter(
            Q(name__icontains=filter_by_name)
            & Q(address__icontains=filter_by_address)
            & Q(province__icontains=filter_by_province)
            # & Q(is_top_level__is_active=filter_by_top)
            & (Q(parent_company__name__icontains=filter_by_parent) | Q(parent_company__name__isnull=True))
            & Q(city__icontains=filter_by_city)
            & Q(postal_code__icontains=filter_by_postal_code)
        ).order_by(order)

        # get pagination, which limits the amount of items returned
        page = self.paginate_queryset(queryset)
        # serialized the filitered, ordered, and paginated data
        serializer = self.get_serializer(page, many=True)
        # create a pangination response, that comes with all the meta data of the page
        paginated_response = self.get_paginated_response(serializer.data).data


        return Response({
            'success': True,
            'count': paginated_response.get('count', 0),
            'next': paginated_response.get('next'),
            'previous': paginated_response.get('previous'),
            'results': paginated_response.get('results')
        },status=status.HTTP_200_OK)

"""
# Function Based Views
"""
#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def broker_company_by_id(request,id):
    
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single record by ID
    #       PATCH: Paritially updates a record by ID
    #       DELETE: Removes a single record by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''

    #Validate Existing Underwriter by ID
    try:
        queryset = BrokerCompany.objects.get(id = id)
    except BrokerCompany.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    #Get by ID
    if request.method == 'GET':
        serializer = BrokerCompanySerializer(queryset)
        return Response(serializer.data)

    #Edit/Update by ID
    elif request.method == 'PATCH':
        serializer = BrokerCompanySerializer(queryset, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Save the updated record
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Delete by ID
    elif request.method == 'DELETE':
        queryset.delete()
        return Response({"message": "Named Insured deleted successfully"}, status=status.HTTP_200_OK)

    
#Use 1 keyword to search across multiple fields
@api_view(['GET'])
def search_company(request):
    query = request.GET.get('query','').strip()
    if not query:
        return Response([],status=status.HTTP_200_OK)
    
    queryset = BrokerCompany.objects.filter(
        Q(name__icontains=query) |
        Q(parent_company__name__icontains=query)
    )

    serializer = BrokerCompanySerializer(queryset, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)



'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Brokerage/Broker - Views

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
"""
# Class Based Views
"""
class InsuranceBrokerPagination(PageNumberPagination):
    page_size = 30

class InsuranceBrokerView(generics.GenericAPIView):
    queryset = InsuranceBroker.objects.all()
    serializer_class = InsuredBrokerSerializer
    pagination_class = InsuranceBrokerPagination

    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)    
    
    #Create
    def post(self, request, *args, **kwargs):
        #   ''''''''''''''''''''''''''''''''''''
        #       POST: create new Broker Agent
        #   ''''''''''''''''''''''''''''''''''''

        serializer = self.get_serializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    

    #Read
    def get(self, request, *args, **kwargs):
        #  ''''''''''''''''''''''''''''''''''''''''''''''''
        #
        #       GET: Get all Broker Agents
        #        - has filtering, ordering, and pagination
        #
        #  ''''''''''''''''''''''''''''''''''''''''''''''''

        # search for Query parameters to filter and order by
        filter_by_first_name = request.GET.get('firstname','').strip()
        filter_by_last_name = request.GET.get('lastname','').strip()
        filter_by_title = request.GET.get('title','').strip()
        filter_by_phone_number = request.GET.get('phone','').strip()
        filter_by_email = request.GET.get('email','').strip()
        filter_by_broker_company_name = request.GET.get('parent','').strip()
        order = request.GET.get('order','first_name').strip()

        # create queryset
        queryset = self.get_queryset().filter(
            Q(first_name__icontains=filter_by_first_name)
            & Q(last_name__icontains=filter_by_last_name)
            & (Q(title__icontains=filter_by_title)| Q(title__isnull=True))
            & (Q(phone_number__icontains=filter_by_phone_number)| Q(phone_number__isnull=True))
            & (Q(email__icontains=filter_by_email)| Q(email__isnull=True))
            & (Q(broker_company__name__icontains=filter_by_broker_company_name))
        ).order_by(order)

        # get pagination, which limits the amount of items returned
        page = self.paginate_queryset(queryset)
        # serialized the filitered, ordered, and paginated data
        serializer = self.get_serializer(page, many=True)
        # create a pangination response, that comes with all the meta data of the page
        paginated_response = self.get_paginated_response(serializer.data).data


        return Response({
            'success': True,
            'count': paginated_response.get('count', 0),
            'next': paginated_response.get('next'),
            'previous': paginated_response.get('previous'),
            'results': paginated_response.get('results')
        },status=status.HTTP_200_OK)

"""
# Function Based Views
"""
#Meant to handle by ID
@api_view(['GET','PATCH','DELETE'])
def insurance_broker_by_id(request,id):
    
    #  ''''''''''''''''''''''''''''''''''''''''''''''''
    #
    #       GET: Returns a single Named Insured by ID
    #       PATCH: Paritially updates a Named Insured by ID
    #       DELETE: Removes a single Named Insured by ID
    #
    #  ''''''''''''''''''''''''''''''''''''''''''''''''

    #Validate Existing Underwriter by ID
    try:
        queryset = InsuranceBroker.objects.get(id = id)
    except InsuranceBroker.DoesNotExist:
        return Response({"message: Does not Exist"},status=status.HTTP_404_NOT_FOUND)    

    #Get by ID
    if request.method == 'GET':
        serializer = InsuredBrokerSerializer(queryset)
        return Response(serializer.data)

    #Edit/Update by ID
    elif request.method == 'PATCH':
        serializer = InsuredBrokerSerializer(queryset, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()  # Save the updated record
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Delete by ID
    elif request.method == 'DELETE':
        queryset.delete()
        return Response({"message": "Broker deleted successfully"}, status=status.HTTP_200_OK)

@api_view(['GET'])
def search_broker(request):
    if 'broker' in request.path:
        query = request.GET.get('query','').strip()

        if not query:
            return Response([],status=status.HTTP_200_OK)
        
        fields = ['first_name', 'last_name', 'title','email', 'phone_number']
        q_objects = Q()
        
        for field in fields:
            q_objects |= Q(**{f"{field}__icontains": query})
        q_objects |= Q(broker_company__name__icontains=query)
        q_objects |= Q(full_name__icontains=query)
        
        brokers = InsuranceBroker.objects.annotate(
            full_name=Concat(
                'first_name',
                Value(' '),
                'last_name',
                output_field=CharField()
            )
        ).filter(q_objects)
        
        serializer = InsuredBrokerSerializer(brokers, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)
        

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    Brokerage - Bulk Actions

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
@api_view(['POST'])
def bulk_create(request):
    if not isinstance(request.data, list):
        return Response({"error": "Expected a list of objects"}, status=status.HTTP_400_BAD_REQUEST)
    
    data = []
    
    if 'company' in request.path: 
        for item in request.data:
            serializer = BrokerCompanySerializer(data=item)
            if serializer.is_valid():
                data.append(BrokerCompany(**serializer.validated_data))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Bulk create in the database
        BrokerCompany.objects.bulk_create(data)

    if 'broker' in request.path: 

        for item in request.data:
            serializer = InsuredBrokerSerializer(data=item)
            if serializer.is_valid():
                data.append(InsuranceBroker(**serializer.validated_data))
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Bulk create in the database
        InsuranceBroker.objects.bulk_create(data)

    return Response({"message": "Bulk create successful"}, status=status.HTTP_201_CREATED)

def create_company_by_name(company_name):
    try:
        broker_company = BrokerCompany.objects.create(name=company_name)
        return broker_company
    except IntegrityError as e:
        return Response(status=status.HTTP_409_CONFLICT)
